public class ParameterParser {
  public FileItem getFileItem(String name) {
    return new FileItem();
	}
}

