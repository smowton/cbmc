public class TaintSink {
  public static void receive_taint(char c) {
  }
}

