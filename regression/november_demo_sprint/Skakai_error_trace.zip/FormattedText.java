public class FormattedText {
  public static String processEscapedHtml(String source) {
    return "";
  }
}

