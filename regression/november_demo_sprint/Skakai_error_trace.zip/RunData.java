public class RunData {
	public ParameterParser getParameters() {
    return new ParameterParser();
	}
}

