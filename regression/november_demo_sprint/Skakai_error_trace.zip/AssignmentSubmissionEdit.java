public interface AssignmentSubmissionEdit {
  public void setSubmittedText(String submissionText);
}
