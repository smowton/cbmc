  public interface AssignmentSubmission {
  
  }
  